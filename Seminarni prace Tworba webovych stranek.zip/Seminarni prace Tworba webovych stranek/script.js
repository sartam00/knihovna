// Konfigurace Firebase 
const firebaseConfig = {
  apiKey: "AIzaSyBnqos3SQpZ7MJgYf5hgR_XhJX-eoA9XuA",
  authDomain: "knihovna-44eeb.firebaseapp.com",
  databaseURL: "https://knihovna-44eeb-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "knihovna-44eeb",
  storageBucket: "knihovna-44eeb.appspot.com",
  messagingSenderId: "596694421977",
  appId: "1:596694421977:web:3226478ef3aa02be0289c8"
};

// Inicializace Firebase
const app = firebase.initializeApp(firebaseConfig);
const database = firebase.database();

// Test pripojeni
database.ref('connectionTest').set({
  timestamp: new Date().toISOString()
})
.then(() => console.log("✅ Připojeno k Firebase"))
.catch(error => console.error("❌ Chyba:", error));

// Sprava knih
document.getElementById('bookForm').addEventListener('submit', function(e) {
  e.preventDefault();
  
  const title = document.getElementById('title').value;
  const author = document.getElementById('author').value;
  
  // pridani knihy do databaze
  database.ref('books').push({
    title: title,
    author: author,
    createdAt: firebase.database.ServerValue.TIMESTAMP
  })
  .then(() => {
    document.getElementById('bookForm').reset();
    console.log("Kniha přidána");
  })
  .catch(error => {
    console.error("Chyba při ukládání:", error);
  });
});

// Zobrazení knih
database.ref('books').on('value', (snapshot) => {
  const books = snapshot.val();
  const bookList = document.getElementById('bookList');
  bookList.innerHTML = '';
  
  if (books) {
    Object.keys(books).forEach(key => {
      const book = books[key];
      const bookElement = document.createElement('div');
      bookElement.className = 'book';
      bookElement.innerHTML = `
        <h3>${book.title}</h3>
        <p>Autor: ${book.author}</p>
        <button onclick="deleteBook('${key}')">Smazat</button>
      `;
      bookList.appendChild(bookElement);
    });
  }
});

// Smazani knihy ze seznamu
window.deleteBook = function(key) {
  if (confirm('Opravdu smazat tuto knihu?')) {
    database.ref('books/' + key).remove()
      .then(() => console.log("Kniha smazána"))
      .catch(error => console.error("Chyba:", error));
  }
};